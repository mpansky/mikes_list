import { useCallback, useState, useRef, useMemo } from 'react';
import { Search, ZoomIn, ZoomOut } from 'lucide-react';
import { Logo } from '../components/Logo';
import { Background } from '../components/Background';
import { Navigation } from '../components/Navigation';
import ForceGraph2D from 'react-force-graph-2d';
import { marketMapData } from '../data/marketMap';
import type { NodeObject, LinkObject, ForceGraphMethods } from 'react-force-graph-2d';

interface SearchResult {
  id: string;
  name: string;
}

export function MarketMap() {
  const [selectedNode, setSelectedNode] = useState<NodeObject | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<SearchResult[]>([]);
  const graphRef = useRef<ForceGraphMethods>(null);

  const handleSearch = (event: React.ChangeEvent<HTMLInputElement>) => {
    const query = event.target.value.toLowerCase();
    setSearchQuery(query);
    if (query.length > 0) {
      const results = marketMapData.nodes
        .filter(node =>
          node.name.toLowerCase().includes(query) ||
          (node.description && node.description.toLowerCase().includes(query))
        )
        .slice(0, 5)
        .map(node => ({ id: node.id, name: node.name }));
      setSearchResults(results);
    } else {
      setSearchResults([]);
    }
  };

  const handleZoomIn = () => {
    if (graphRef.current) {
      graphRef.current.zoom(2);
    }
  };

  const handleZoomOut = () => {
    if (graphRef.current) {
      graphRef.current.zoom(0.5);
    }
  };

  const handleNodeClick = useCallback((node: NodeObject) => {
    setSelectedNode(node);
  }, []);

  const filteredData = useMemo(() => {
    if (!searchQuery) return marketMapData;
    const query = searchQuery.toLowerCase();
    const matchingNodes = marketMapData.nodes.filter(node =>
      node.name.toLowerCase().includes(query) ||
      (node.description && node.description.toLowerCase().includes(query))
    );

    const matchingNodeIds = new Set(matchingNodes.map(n => n.id));

    const filteredNodes = marketMapData.nodes.filter(node => matchingNodeIds.has(node.id));
    const filteredLinks = marketMapData.links.filter(link => {
      const sourceId = typeof link.source === 'string' ? link.source : link.source.id;
      const targetId = typeof link.target === 'string' ? link.target : link.target.id;
      return matchingNodeIds.has(sourceId) || matchingNodeIds.has(targetId);
    });

    return {
      nodes: filteredNodes,
      links: filteredLinks
    };
  }, [searchQuery]);

  return (
    <div className="min-h-screen bg-[#020B1C] text-white">
      <Background />
      
      <div className="max-w-7xl mx-auto relative px-4 sm:px-6 lg:px-8">
        <div className="absolute top-4 sm:top-8 left-4 sm:left-8">
          <Logo />
        </div>
        <div className="absolute top-4 sm:top-8 right-4 sm:right-8">
          <Navigation />
        </div>

        <div className="pt-32 pb-16 text-center">
          <h1 className="text-5xl font-bold mb-6">
            <span className="text-[#E63946]">AI</span> Market Map
          </h1>
        </div>
        <div className="flex justify-between items-center mb-4">
          <div className="relative flex-1 max-w-md">
            <input
              type="text"
              placeholder="Search companies and technologies..."
              value={searchQuery}
              onChange={handleSearch}
              className="w-full bg-[#1E3A8A]/20 text-white rounded-lg pl-10 pr-4 py-2 focus:outline-none focus:ring-2 focus:ring-[#3B82F6] border border-[#1E3A8A]/50 focus:border-[#3B82F6]/50"
            />
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
            {searchResults.length > 0 && (
              <div className="absolute w-full mt-2 bg-[#0A1A3A]/95 rounded-lg border border-[#1E3A8A]/50 shadow-lg z-10">
                {searchResults.map(result => (
                  <button
                    key={result.id}
                    onClick={() => {
                      const node = marketMapData.nodes.find(n => n.id === result.id);
                      if (node) handleNodeClick(node as NodeObject);
                      setSearchQuery('');
                      setSearchResults([]);
                    }}
                    className="w-full text-left px-4 py-2 hover:bg-[#1E3A8A]/30 text-gray-300 hover:text-white transition-colors"
                  >
                    {result.name}
                  </button>
                ))}
              </div>
            )}
          </div>
          <div className="flex gap-2 ml-4">
            <button
              onClick={handleZoomIn}
              className="p-2 bg-[#1E3A8A]/20 hover:bg-[#1E3A8A]/30 rounded-lg border border-[#1E3A8A]/50"
            >
              <ZoomIn className="w-5 h-5" />
            </button>
            <button
              onClick={handleZoomOut}
              className="p-2 bg-[#1E3A8A]/20 hover:bg-[#1E3A8A]/30 rounded-lg border border-[#1E3A8A]/50"
            >
              <ZoomOut className="w-5 h-5" />
            </button>
          </div>
        </div>

        <div className="bg-[#0A1A3A]/80 backdrop-blur-sm rounded-xl border border-[#1E3A8A]/50 p-4 h-[600px]">
          <ForceGraph2D
            ref={graphRef}
            graphData={filteredData}
            nodeColor={(node: NodeObject) => node.color || '#6366F1'}
            nodeLabel="name"
            linkColor={() => 'rgba(30, 58, 138, 0.3)'}
            linkWidth={2}
            nodeRelSize={8}
            backgroundColor="transparent"
            width={800}
            height={550}
            onNodeClick={handleNodeClick}
          />
        </div>

        {selectedNode && (
          <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 z-50">
            <div className="bg-[#0A1A3A]/95 rounded-xl p-8 max-w-2xl w-full relative">
              <button
                onClick={() => setSelectedNode(null)}
                className="absolute right-4 top-4 text-gray-400 hover:text-white"
              >
                ×
              </button>
              <h3 className="text-2xl font-bold mb-2">{selectedNode.name}</h3>
              <p className="text-gray-400 mb-4">{selectedNode.description}</p>
              {selectedNode.url && (
                <a
                  href={selectedNode.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-[#3B82F6] hover:text-[#E63946] transition-colors"
                >
                  Learn More →
                </a>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}