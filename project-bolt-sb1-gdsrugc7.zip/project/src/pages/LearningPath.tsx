import { BookOpen, Brain, Code, Cpu, Dna, Rocket, CheckCircle2, Clock } from 'lucide-react';
import { Logo } from '../components/Logo';
import { Navigation } from '../components/Navigation';
import { useState } from 'react';
import { celebrateCompletion } from '../utils/confetti';

type ModuleStatus = 'completed' | 'in-progress' | 'upcoming';

interface LearningModule {
  title: string;
  description: string;
  icon: React.ReactNode;
  status: ModuleStatus;
  estimatedTime: string;
  topics: Array<{
    name: string;
    url?: string;
  }>;
}

export function LearningPath() {
  const [modules, setModules] = useState<LearningModule[]>(learningModules);

  const handleComplete = (index: number) => {
    setModules(prevModules => {
      const newModules = [...prevModules];

      // Mark current module as completed
      newModules[index] = { ...newModules[index], status: 'completed' };

      // Set next module to in-progress if it exists
      if (index + 1 < newModules.length) {
        newModules[index + 1] = { ...newModules[index + 1], status: 'in-progress' };
      }

      // Check if all modules are completed
      const allCompleted = newModules.every(module => module.status === 'completed');
      if (allCompleted) {
        celebrateCompletion();
      }

      return newModules;
    });
  };

  const getStatusColor = (status: ModuleStatus) => {
    switch (status) {
      case 'completed':
        return 'text-green-500';
      case 'in-progress':
        return 'text-blue-500';
      default:
        return 'text-gray-400';
    }
  };

  const getStatusIcon = (status: ModuleStatus) => {
    switch (status) {
      case 'completed':
        return <CheckCircle2 className="w-5 h-5 text-green-500" />;
      case 'in-progress':
        return <Clock className="w-5 h-5 text-blue-500 animate-pulse" />;
      default:
        return <Clock className="w-5 h-5 text-gray-400" />;
    }
  };

  return (
    <div className="max-w-7xl mx-auto relative">
      <div className="absolute top-4 sm:top-8 left-4 sm:left-8">
        <Logo />
      </div>
      <div className="absolute top-4 sm:top-8 right-4 sm:right-8">
        <Navigation />
      </div>

      <div className="pt-32 pb-16 text-center">
        <h1 className="text-5xl font-bold mb-6">
          <span className="text-[#E63946]">AI Learning</span> Path
        </h1>
        <p className="text-gray-400 max-w-2xl mx-auto">
          A comprehensive roadmap to master Large Language Models and AI development.
          Track your progress through each module and build a strong foundation in AI.
        </p>
      </div>

      <div className="space-y-8 px-4 relative">
        <div className="absolute left-[2.4rem] top-12 bottom-12 w-0.5 bg-[#1E3A8A]/30"></div>
        {modules.map((module, index) => (
          <div
            key={index}
            className="relative flex gap-8"
          >
            <div className="flex flex-col items-center">
              <div className={`w-12 h-12 rounded-lg bg-[#1E3A8A]/30 flex items-center justify-center ${getStatusColor(module.status)} transition-colors z-10`}>
                {module.icon}
              </div>
            </div>
            <div className="flex-1 bg-[#0A1A3A]/80 backdrop-blur-sm rounded-lg p-6 border border-[#1E3A8A]/50 hover:border-[#3B82F6]/50 transition-all">
              <div className="flex justify-between items-start mb-4">
                <div>
                  <h3 className="font-semibold text-lg flex items-center gap-3">
                    {module.title}
                    {getStatusIcon(module.status)}
                  </h3>
                  <span className="text-sm text-gray-400">{module.estimatedTime}</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className={`text-sm ${getStatusColor(module.status)}`}>
                    {module.status === 'completed' ? 'Completed' : 
                    module.status === 'in-progress' ? (
                      <button
                        onClick={() => handleComplete(index)}
                        className="bg-[#1E3A8A]/80 hover:bg-[#1E3A8A] px-3 py-1 rounded text-white transition-colors"
                      >
                        Mark Complete
                      </button>
                    ) : 'Coming Soon'}
                  </span>
                </div>
              </div>
              <p className="text-gray-400 text-sm mb-4">{module.description}</p>
              <div className="space-y-2">
                <h4 className="text-sm font-semibold text-gray-300">Key Topics:</h4>
                <ul className="grid grid-cols-2 gap-2">
                  {module.topics.map((topic, i) => (
                    <li key={i} className="text-sm text-gray-400 flex items-center gap-2">
                      <div className="w-1.5 h-1.5 rounded-full bg-[#3B82F6]" />
                      {topic.url ? (
                        <a
                          href={topic.url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="hover:text-[#3B82F6] transition-colors"
                        >
                          {topic.name}
                        </a>
                      ) : topic.name}
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

const learningModules: LearningModule[] = [
  {
    title: 'Foundations',
    description: 'Build a strong foundation in machine learning and deep learning fundamentals through structured courses and hands-on tutorials.',
    icon: <BookOpen className="w-6 h-6" />,
    status: 'in-progress',
    estimatedTime: '1-2 hours',
    topics: [
      { name: 'Fast.ai Deep Learning', url: 'https://course.fast.ai/' },
      { name: 'Google ML Crash Course', url: 'https://developers.google.com/machine-learning/crash-course' },
      { name: 'Neural Networks Basics', url: 'https://www.youtube.com/playlist?list=PLZHQObOWTQDNU6R1_67000Dx_ZCJB-3pi' },
      { name: 'PyTorch Fundamentals', url: 'https://pytorch.org/tutorials/' },
      { name: 'TensorFlow Basics', url: 'https://www.tensorflow.org/tutorials' },
      { name: 'Mathematics for ML', url: 'https://www.coursera.org/specializations/mathematics-machine-learning' },
    ],
  },
  {
    title: 'LLM Architecture',
    description: 'Deep dive into transformer architectures, attention mechanisms, and the evolution of language models through research papers and tutorials.',
    icon: <Brain className="w-6 h-6" />,
    status: 'upcoming',
    estimatedTime: '1-2 hours',
    topics: [
      { name: 'Attention Is All You Need', url: 'https://arxiv.org/abs/1706.03762' },
      { name: 'BERT & GPT Evolution', url: 'https://arxiv.org/abs/1810.04805' },
      { name: 'Scaling Laws', url: 'https://arxiv.org/abs/2001.08361' },
      { name: 'Model Architectures', url: 'https://arxiv.org/abs/2203.02155' },
      { name: 'Mixture of Experts', url: 'https://arxiv.org/abs/2401.04088' },
      { name: 'Context Windows', url: 'https://arxiv.org/abs/2307.09288' },
    ],
  },
  {
    title: 'Training & Fine-tuning',
    description: 'Master efficient training and fine-tuning techniques using modern tools and frameworks.',
    icon: <Dna className="w-6 h-6" />,
    status: 'upcoming',
    estimatedTime: '1-2 hours',
    topics: [
      { name: 'PEFT & LoRA', url: 'https://github.com/huggingface/peft' },
      { name: 'QLoRA & Quantization', url: 'https://arxiv.org/abs/2305.14314' },
      { name: 'Instruction Tuning', url: 'https://arxiv.org/abs/2203.02155' },
      { name: 'Constitutional AI', url: 'https://arxiv.org/abs/2212.08073' },
      { name: 'PEFT Techniques', url: 'https://huggingface.co/blog/peft' },
      { name: 'Training Optimization', url: 'https://www.deepspeed.ai/' },
    ],
  },
  {
    title: 'Practical Implementation',
    description: 'Hands-on experience with popular frameworks, tools, and best practices for LLM development and deployment.',
    icon: <Code className="w-6 h-6" />,
    status: 'upcoming',
    estimatedTime: '1-2 hours',
    topics: [
      { name: 'Hugging Face Tools', url: 'https://huggingface.co/docs' },
      { name: 'LangChain', url: 'https://python.langchain.com/docs/get_started/introduction' },
      { name: 'vLLM & Inference', url: 'https://github.com/vllm-project/vllm' },
      { name: 'LlamaIndex & RAG', url: 'https://www.llamaindex.ai/' },
      { name: 'FastChat & Serving', url: 'https://github.com/lm-sys/FastChat' },
      { name: 'LocalAI Setup', url: 'https://github.com/go-skynet/LocalAI' },
    ],
  },
  {
    title: 'Advanced Topics',
    description: 'Explore cutting-edge techniques and advanced concepts in LLM development and research.',
    icon: <Cpu className="w-6 h-6" />,
    status: 'upcoming',
    estimatedTime: '1-2 hours',
    topics: [
      { name: 'RLHF', url: 'https://huggingface.co/blog/rlhf' },
      { name: 'Multimodal LLMs', url: 'https://arxiv.org/abs/2303.08774' },
      { name: 'Model Alignment', url: 'https://arxiv.org/abs/2203.02155' },
      { name: 'Sparse Attention', url: 'https://arxiv.org/abs/2305.13048' },
      { name: 'Model Merging', url: 'https://arxiv.org/abs/2306.01708' },
      { name: 'Latest Research', url: 'https://paperswithcode.com/task/language-modelling' },
    ],
  },
  {
    title: 'Production Deployment',
    description: 'Master the tools and techniques for efficient LLM deployment, scaling, and monitoring in production.',
    icon: <Rocket className="w-6 h-6" />,
    status: 'upcoming',
    estimatedTime: '1-2 hours',
    topics: [
      { name: 'DeepSpeed & vLLM', url: 'https://www.deepspeed.ai/' },
      { name: 'GGML & llama.cpp', url: 'https://github.com/ggerganov/llama.cpp' },
      { name: 'TensorRT-LLM', url: 'https://github.com/NVIDIA/TensorRT-LLM' },
      { name: 'Cloud Deployment', url: 'https://aws.amazon.com/sagemaker/' },
      { name: 'Monitoring Tools', url: 'https://wandb.ai/' },
      { name: 'Cost Management', url: 'https://cloud.google.com/vertex-ai' },
    ],
  },
];