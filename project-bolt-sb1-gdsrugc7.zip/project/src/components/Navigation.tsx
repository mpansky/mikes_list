import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Menu, X } from 'lucide-react';

export function Navigation() {
  const [isOpen, setIsOpen] = useState(false);
  const navigate = useNavigate();

  const handleNavigation = (path: string) => {
    setIsOpen(false);
    navigate(path);
  };

  return (
    <div className="relative">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="text-gray-400 hover:text-white transition-colors p-2"
      >
        {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
      </button>

      {isOpen && (
        <div className="absolute right-0 mt-2 w-48 bg-[#0A1A3A]/95 backdrop-blur-sm rounded-lg shadow-lg border border-[#1E3A8A]/30 overflow-hidden z-50">
          <div className="py-1">
            <button
              onClick={() => handleNavigation('/')}
              className="w-full text-left px-4 py-2 text-gray-300 hover:bg-[#1E3A8A]/30 hover:text-white transition-colors"
            >
              Resources
            </button>
            <button
              onClick={() => handleNavigation('/learning-path')}
              className="w-full text-left px-4 py-2 text-gray-300 hover:bg-[#1E3A8A]/30 hover:text-white transition-colors"
            >
              AI Learning Path
            </button>
            <button
              onClick={() => handleNavigation('/market-map')}
              className="w-full text-left px-4 py-2 text-gray-300 hover:bg-[#1E3A8A]/30 hover:text-white transition-colors"
            >
              AI Market Map
            </button>
          </div>
        </div>
      )}
    </div>
  );
}