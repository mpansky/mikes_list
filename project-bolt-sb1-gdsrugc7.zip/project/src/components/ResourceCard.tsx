import React from 'react';
import { ResourceSection } from '../types/resource';
import { ChevronRight } from 'lucide-react';
import { Modal } from './Modal';

interface ResourceCardProps {
  section: ResourceSection;
}

export function ResourceCard({ section }: ResourceCardProps) {
  const [isModalOpen, setIsModalOpen] = React.useState(false);

  const displayItems = section.items.slice(0, 5);

  return (
    <>
      <div className="bg-[#0A1A3A]/80 backdrop-blur-sm rounded-lg p-6 hover:bg-[#0A1A8A] transition-colors border border-[#1E3A8A]/50 shadow-lg flex flex-col min-h-[32rem] max-h-[32rem] group">
        <h3 className="text-xl font-semibold mb-2 text-white">{section.title}</h3>
        <p className="text-gray-400 text-sm mb-4">{section.description}</p>
        <ul className="space-y-2 flex-1 min-h-0">
          {displayItems.map((item, index) => (
            <li key={index}>
              {item.link ? (
                <a
                  href={item.link}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center text-gray-300 hover:text-white px-3 py-2 rounded-md hover:bg-[#1E3A8A]/30 transition-all group"
                >
                  <span className="w-2.5 h-2.5 bg-[#3B82F6] rounded-full mr-3 flex-shrink-0 group-hover:bg-[#E63946] transition-colors" />
                  <span className="line-clamp-2">{item.title}</span>
                </a>
              ) : (
                <div className="flex items-center text-gray-300 px-3 py-2">
                  <span className="w-2.5 h-2.5 bg-[#3B82F6] rounded-full mr-3 flex-shrink-0" />
                  <span className="line-clamp-2">{item.title}</span>
                </div>
              )}
            </li>
          ))}
        </ul>
        <div className="flex justify-center mt-4 pt-4 border-t border-[#1E3A8A]/30">
          <button
            onClick={() => setIsModalOpen(true)}
            className="w-full px-4 py-2 bg-[#1E3A8A]/80 hover:bg-[#1E3A8A] rounded-lg text-sm font-medium transition-colors flex items-center justify-center gap-2 border border-[#3B82F6]/30 hover:border-[#3B82F6]/50"
          >
            View all ({section.items.length}) <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>
      <Modal
        section={section}
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
      />
    </>
  );
}