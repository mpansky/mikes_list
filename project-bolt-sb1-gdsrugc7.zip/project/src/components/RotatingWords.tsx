import { useEffect, useState } from 'react';

const words = ['Learning', 'Adapting', 'Growing'];
const ROTATION_INTERVAL = 2000; // 2 seconds per word

export function RotatingWords() {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isAnimating, setIsAnimating] = useState(false);

  useEffect(() => {
    const interval = setInterval(() => {
      setIsAnimating(true);
      setTimeout(() => {
        setCurrentIndex((current) => (current + 1) % words.length);
        setIsAnimating(false);
      }, 500); // Half of the transition time
    }, ROTATION_INTERVAL);

    return () => clearInterval(interval);
  }, []);

  return (
    <span
      className={`inline-block transition-all duration-500 perspective-1000 ${
        isAnimating 
          ? 'opacity-90 transform-style-3d rotate-x-90' 
          : 'opacity-100 transform-style-3d rotate-x-0'
      }`}
      style={{
        perspective: '1000px',
        transformStyle: 'preserve-3d',
        transition: 'all 0.5s cubic-bezier(0.4, 0, 0.2, 1)'
      }}
    >
      {words[currentIndex]}
    </span>
  );
}