import { type FC } from 'react';
import { X } from 'lucide-react';
import { ResourceSection } from '../types/resource';
import { Background } from './Background';

interface ModalProps {
  section: ResourceSection;
  isOpen: boolean;
  onClose: () => void;
}

export const Modal: FC<ModalProps> = ({ section, isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 overflow-hidden">
      <div className="fixed inset-0 bg-black/60 backdrop-blur-sm" onClick={onClose} />
      <div className="relative w-full max-w-4xl bg-[#0A1A3A]/95 rounded-xl shadow-2xl max-h-[90vh] flex flex-col">
        <Background />
        <div className="relative z-10 p-8 overflow-y-auto custom-scrollbar">
          <button
            onClick={onClose}
            className="absolute right-4 top-4 text-gray-400 hover:text-white transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
          
          <h2 className="text-3xl font-bold mb-2 sticky top-0 bg-[#0A1A3A]/95 pt-2 pb-4 -mt-2">{section.title}</h2>
          <p className="text-gray-400 mb-8">{section.description}</p>
          
          <div className="space-y-8">
            {section.items.map((item, index) => (
              <div
                key={index}
                className="bg-[#1E3A8A]/20 p-6 rounded-lg border border-[#3B82F6]/30 hover:border-[#3B82F6]/50 transition-colors group hover:bg-[#1E3A8A]/30"
              >
                <div className="flex items-center gap-4 mb-2">
                  {item.link ? (
                    <a
                      href={item.link}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center hover:text-[#3B82F6] transition-all px-4 py-2 rounded-md hover:bg-[#1E3A8A]/50 -ml-4"
                    >
                      <span className="w-2.5 h-2.5 bg-[#3B82F6] rounded-full mr-3 flex-shrink-0" />
                      <h3 className="text-lg font-semibold">{item.title}</h3>
                    </a>
                  ) : (
                    <>
                      <span className="w-2.5 h-2.5 bg-[#3B82F6] rounded-full mr-3 flex-shrink-0" />
                      <h3 className="text-lg font-semibold">{item.title}</h3>
                    </>
                  )}
                </div>
                {item.description && (
                  <p className="text-gray-400 text-sm ml-6">{item.description}</p>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}