import { useState } from 'react';
import { X } from 'lucide-react';

export function ConvaiWidget() {
  const [isVisible, setIsVisible] = useState(true);

  if (!isVisible) return <div />;

  return (
    <div className="fixed bottom-0 right-0 z-[9998]">
      <button
        onClick={() => setIsVisible(false)}
        className="absolute -top-3 -right-3 z-[9999] bg-[#E63946] hover:bg-[#1E3A8A] text-white p-1.5 rounded-full transition-colors shadow-lg"
        aria-label="Close AI Assistant"
      >
        <X className="w-4 h-4" />
      </button>
      <elevenlabs-convai agent-id="7TQQ6xobFYkt6f5YllyN" />
    </div>
  );
}