export function Logo() {
  return (
    <div className="flex items-center gap-3">
      <div className="w-10 h-10 bg-white rounded-lg flex items-center justify-center p-2">
        <div className="relative w-full h-full">
          <span className="absolute inset-0 flex items-center justify-center text-[#020B1C] font-bold text-2xl">M</span>
          <span className="absolute bottom-0 right-0 w-3 h-3 flex items-center justify-center">
            <span className="block w-2 h-2 border-2 border-[#020B1C] rounded-sm transform translate-x-[-2px] translate-y-[-2px]" />
          </span>
        </div>
      </div>
      <span className="text-xl font-semibold text-white">Mike's List</span>
    </div>
  );
}