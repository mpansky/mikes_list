import { useNavigate } from 'react-router-dom';

export function Logo() {
  const navigate = useNavigate();

  return (
    <div 
      className="flex items-center gap-4 sm:gap-3 p-2 cursor-pointer hover:opacity-80 transition-opacity" 
      onClick={() => navigate('/')}
    >
      <div className="w-10 h-10 bg-gradient-to-br from-[#1E3A8A] to-[#3B82F6] rounded-lg flex items-center justify-center p-2 relative group shadow-lg">
        <div className="absolute inset-0 bg-gradient-to-br from-[#3B82F6] to-[#1E3A8A] rounded-lg opacity-0 group-hover:opacity-100 transition-opacity"></div>
        <div className="relative z-10 w-full h-full flex flex-col justify-center items-center">
          <div className="w-6 h-4 border-2 border-white rounded-sm mb-1"></div>
          <div className="w-4 h-0.5 bg-white rounded-full"></div>
          <div className="w-3 h-0.5 bg-white rounded-full mt-1"></div>
        </div>
        <div className="absolute -right-1 -bottom-1 w-3 h-3 bg-[#E63946] rounded-full border-2 border-[#020B1C] shadow-lg"></div>
      </div>
      <span className="text-xl font-semibold text-white whitespace-nowrap">Mike's List</span>
    </div>
  );
}