export const marketMapData = {
  nodes: [
    // Central Infrastructure Node
    { id: 'infrastructure', name: 'Infrastructure', group: 'core', description: 'Core infrastructure connecting all AI system components', color: '#E63946' },
    
    // Platform Layer
    { id: 'platform', name: 'Platform', group: 'core', description: 'Foundation infrastructure for AI systems', color: '#3B82F6' },
    { id: 'langserve', name: 'LangServe', group: 'platform', description: 'Hosting platform designed for deploying and managing large language models at scale', url: 'https://www.langserve.ai', icon: 'logos:langchain' },
    { id: 'e2b', name: 'E2B', group: 'platform', description: 'Platform that bridges the gap between developers and enterprises by offering robust tools to deploy, manage, and scale machine learning models', url: 'https://www.e2b.dev' },
    { id: 'ollama', name: 'Ollama', group: 'platform', description: 'Infrastructure for hosting and deploying AI applications with optimized resource usage', url: 'https://www.ollama.ai' },
    { id: 'openai', name: 'OpenAI', group: 'platform', description: 'Leading AI research organization that develops advanced AI models and technologies', url: 'https://www.openai.com', icon: 'simple-icons:openai' },
    { id: 'anthropic', name: 'Anthropic', group: 'platform', description: 'Focuses on AI safety and research, developing AI systems that are interpretable and aligned with human intentions', url: 'https://www.anthropic.com', icon: 'simple-icons:anthropic' },
    { id: 'cohere', name: 'Cohere', group: 'platform', description: 'Provides natural language processing models and tools for business applications', url: 'https://www.cohere.ai', icon: 'simple-icons:cohere' },
    
    // Memory Layer
    { id: 'memory', name: 'Memory', group: 'core', description: 'Data storage and retrieval systems', color: '#10B981' },
    { id: 'whyhowai', name: 'WhyHowAI', group: 'memory', description: 'Specializes in creating personalized AI experiences through adaptive user data training', url: 'https://www.whyhowai.com' },
    { id: 'cognee', name: 'Cognee', group: 'memory', description: 'AI-powered personalization platform for delivering tailored customer experiences', url: 'https://www.cognee.com' },
    { id: 'graphlit', name: 'Graphlit', group: 'memory', description: 'Graph-based machine learning tools for enhanced personalization and context understanding', url: 'https://www.graphlit.ai' },
    { id: 'pinecone', name: 'Pinecone', group: 'memory', description: 'Vector database optimized for high-performance, real-time machine learning applications', url: 'https://www.pinecone.io', icon: 'logos:pinecone' },
    { id: 'chroma', name: 'Chroma', group: 'memory', description: 'Vector database designed for AI applications with memory and search capabilities', url: 'https://www.trychroma.com', icon: 'logos:chromadb' },
    { id: 'weaviate', name: 'Weaviate', group: 'memory', description: 'Open-source vector search engine for semantic search and contextual understanding', url: 'https://www.weaviate.io' },
    
    // Planning Layer
    { id: 'planning', name: 'Planning & Orchestration', group: 'core', description: 'Workflow management and process automation', color: '#6366F1' },
    { id: 'inngest', name: 'Inngest', group: 'planning', description: 'Event-driven architecture for building serverless workflows', url: 'https://www.inngest.com' },
    { id: 'hatchet', name: 'Hatchet', group: 'planning', description: 'Process automation and orchestration platform for developers', url: 'https://www.hatchet.dev' },
    { id: 'trigger', name: 'Trigger.dev', group: 'planning', description: 'Workflow automation platform for connecting APIs and services', url: 'https://www.trigger.dev' },
    { id: 'dspy', name: 'DSPy', group: 'planning', description: 'Data science orchestration platform for streamlining model deployment and monitoring', url: 'https://www.dspy.ai' },
    { id: 'autogen', name: 'AutoGen', group: 'planning', description: 'Specializes in AI orchestration tools for seamless workflow execution', url: 'https://www.autogen.ai' },
    { id: 'langgraph', name: 'LangGraph', group: 'planning', description: 'Orchestration frameworks for natural language processing models', url: 'https://www.langgraph.com' },
    
    // Action Layer
    { id: 'action', name: 'Action', group: 'core', description: 'Model deployment and inference', color: '#F59E0B' },
    { id: 'tinyfish', name: 'Tiny Fish', group: 'action', description: 'UI automation tools for streamlining repetitive tasks across software interfaces', url: 'https://www.tinyfish.com' },
    { id: 'superagent', name: 'Superagent', group: 'action', description: 'Platform for building and managing AI agents for workflow automation', url: 'https://www.superagent.ai' },
    { id: 'browse-ai', name: 'Browse AI', group: 'action', description: 'No-code web automation tool for data extraction and monitoring', url: 'https://www.browse.ai' },
    { id: 'reworkd', name: 'Reworkd', group: 'action', description: 'Automation solutions that streamline business processes through AI-driven automation', url: 'https://www.reworkd.ai' },
    { id: 'basepilot', name: 'Basepilot', group: 'action', description: 'AI-driven tools for automating administrative tasks and workflows', url: 'https://www.basepilot.ai' },
    { id: 'induced', name: 'Induced', group: 'action', description: 'AI-based workflow automation solutions for enterprise environments', url: 'https://www.induced.ai' },

    // Apps Layer
    { id: 'apps', name: 'Apps', group: 'core', description: 'End-user applications', color: '#EC4899' },
    { id: 'airops', name: 'AirOps', group: 'apps', description: 'Specializes in automating data workflows and streamlining data processing tasks', url: 'https://www.airops.com' },
    { id: 'cognition', name: 'Cognition', group: 'apps', description: 'AI-driven solutions for enhancing organizational decision-making processes', url: 'https://www.cognition.com' },
    { id: 'perplexity', name: 'Perplexity', group: 'apps', description: 'AI-powered search engine providing direct answers through natural language processing', url: 'https://www.perplexity.ai' },
    { id: 'gradial', name: 'Gradial', group: 'apps', description: 'AI-powered tools for understanding and predicting customer behavior', url: 'https://www.gradial.ai' },
    { id: 'cognosys', name: 'Cognosys', group: 'apps', description: 'AI solutions for automating and enhancing business processes', url: 'https://www.cognosys.ai' },
    { id: 'ema', name: 'Ema', group: 'apps', description: 'AI agents designed to assist with personal and professional tasks', url: 'https://www.ema.ai' }
  ],
  links: [
    // Infrastructure connections
    { source: 'infrastructure', target: 'platform' },
    { source: 'infrastructure', target: 'memory' },
    { source: 'infrastructure', target: 'planning' },
    { source: 'infrastructure', target: 'action' },
    { source: 'infrastructure', target: 'apps' },
    
    // Platform connections
    { source: 'platform', target: 'langserve' },
    { source: 'platform', target: 'e2b' },
    { source: 'platform', target: 'ollama' },
    { source: 'platform', target: 'openai' },
    { source: 'platform', target: 'anthropic' },
    { source: 'platform', target: 'cohere' },
    
    // Memory connections
    { source: 'memory', target: 'whyhowai' },
    { source: 'memory', target: 'cognee' },
    { source: 'memory', target: 'graphlit' },
    { source: 'memory', target: 'pinecone' },
    { source: 'memory', target: 'chroma' },
    { source: 'memory', target: 'weaviate' },
    
    // Planning connections
    { source: 'planning', target: 'inngest' },
    { source: 'planning', target: 'hatchet' },
    { source: 'planning', target: 'trigger' },
    { source: 'planning', target: 'dspy' },
    { source: 'planning', target: 'autogen' },
    { source: 'planning', target: 'langgraph' },

    // Action connections
    { source: 'action', target: 'tinyfish' },
    { source: 'action', target: 'superagent' },
    { source: 'action', target: 'browse-ai' },
    { source: 'action', target: 'reworkd' },
    { source: 'action', target: 'basepilot' },
    { source: 'action', target: 'induced' },

    // Apps connections
    { source: 'apps', target: 'airops' },
    { source: 'apps', target: 'cognition' },
    { source: 'apps', target: 'perplexity' },
    { source: 'apps', target: 'gradial' },
    { source: 'apps', target: 'cognosys' },
    { source: 'apps', target: 'ema' },

    // Cross-layer connections
    { source: 'platform', target: 'memory' },
    { source: 'memory', target: 'planning' },
    { source: 'planning', target: 'action' },
    { source: 'action', target: 'apps' }
  ]
};