import React from 'react';
import { resourceSections } from './data/resources';
import { ResourceCard } from './components/ResourceCard';
import { SearchBar } from './components/SearchBar';
import { searchResources } from './utils/search';
import { Wand2 } from 'lucide-react';
import { Logo } from './components/Logo';
import { Background } from './components/Background';

function App() {
  const [searchQuery, setSearchQuery] = React.useState('');
  const filteredSections = searchResources(resourceSections, searchQuery);

  return (
    <div className="min-h-screen bg-[#020B1C] text-white py-12 px-4 sm:px-6 lg:px-8">
      <Background />
      <div className="max-w-7xl mx-auto">
        <div className="absolute top-8 left-8">
          <Logo />
        </div>
        <header className="text-center mb-12">
          <h1 className="text-6xl font-bold mb-4">
            <span className="text-[#E63946]">Always</span>{' '}
            <span className="text-white">Learning</span>
          </h1>
          <p className="text-gray-400 mb-8">
            Your one-stop destination for all the resources you need in your LLM program.
          </p>
          <div className="relative inline-block">
            <button disabled className="bg-[#1E3A8A]/80 hover:bg-[#1E3A8A] text-white px-8 py-3 rounded-lg font-medium transition-colors backdrop-blur-sm border border-[#3B82F6]/30 shadow-lg flex items-center gap-2 cursor-not-allowed opacity-90">
              <Wand2 className="w-5 h-5" />
              AI Learning Path
            </button>
            <div className="absolute -top-3 -right-3 bg-[#E63946] text-white text-xs px-2 py-1 rounded-full font-medium transform rotate-12 shadow-lg">
              Coming Soon
            </div>
          </div>
        </header>

        <SearchBar onSearch={setSearchQuery} />

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 auto-rows-fr">
          {filteredSections.map((section, index) => (
            <ResourceCard key={index} section={section} />
          ))}
        </div>

        <footer className="mt-16 text-center">
          <h2 className="text-2xl font-semibold mb-4">Want to be added to Mike's List?</h2>
          <div className="flex justify-center gap-4">
            <a
              href="mailto:mikepansky@gmail.com"
              className="bg-[#1E3A8A]/80 hover:bg-[#1E3A8A] text-white px-8 py-3 rounded-lg font-medium transition-colors backdrop-blur-sm border border-[#3B82F6]/30 shadow-lg flex items-center gap-2"
            >
              Contact
            </a>
          </div>
        </footer>
      </div>
    </div>
  );
}

export default App;