declare module 'vanta/dist/vanta.net.min' {
  import { Object3D } from 'three';
  
  interface VantaNetOptions {
    el: HTMLElement;
    THREE: any;
    mouseControls?: boolean;
    touchControls?: boolean;
    gyroControls?: boolean;
    scale?: number;
    scaleMobile?: number;
    color?: number;
    points?: number;
    maxDistance?: number;
    spacing?: number;
    backgroundColor?: number;
  }

  interface VantaEffect {
    destroy: () => void;
  }

  function NET(options: VantaNetOptions): VantaEffect;
  export default NET;
}