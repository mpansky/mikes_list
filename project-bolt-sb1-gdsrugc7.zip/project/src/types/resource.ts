export interface Resource {
  title: string;
  icon?: string;
  link?: string;
  description?: string;
}

export interface ResourceSection {
  title: string;
  description: string;
  items: Resource[];
}