declare module 'react-force-graph-2d' {
  import { ForceGraphProps } from 'react-force-graph-2d';
  
  export interface NodeObject {
    id: string;
    name: string;
    group?: string;
    description?: string;
    url?: string;
    color?: string;
    icon?: string;
    highlighted?: boolean;
    x?: number;
    y?: number;
  }

  export interface LinkObject {
    source: string | NodeObject;
    target: string | NodeObject;
    highlighted?: boolean;
  }

  export interface ForceGraphMethods {
    zoom(k?: number): void;
    centerAt(x?: number, y?: number): void;
  }

  export interface ForceGraph2DProps {
    graphData: { nodes: NodeObject[]; links: LinkObject[] };
    nodeColor?: string | ((node: NodeObject) => string);
    nodeLabel?: string | ((node: NodeObject) => string);
    linkColor?: string | ((link: LinkObject) => string);
    linkWidth?: number;
    nodeRelSize?: number;
    nodeCanvasObject?: (node: NodeObject, ctx: CanvasRenderingContext2D, scale: number) => void;
    onNodeClick?: (node: NodeObject) => void;
    onNodeHover?: (node: NodeObject | null) => void;
    width?: number;
    height?: number;
    cooldownTicks?: number;
    d3AlphaDecay?: number;
    d3VelocityDecay?: number;
    backgroundColor?: string;
  }

  const ForceGraph2D: React.ForwardRefExoticComponent<
    ForceGraph2DProps & React.RefAttributes<ForceGraphMethods>
  >;

  export default ForceGraph2D;
}