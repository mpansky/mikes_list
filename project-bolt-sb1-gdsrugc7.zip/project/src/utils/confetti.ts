import confetti from 'canvas-confetti';

export function celebrateCompletion() {
  const count = 200;
  const defaults = {
    origin: { y: 0.7 },
    zIndex: 1000,
  };

  function fire(particleRatio: number, opts: confetti.Options) {
    confetti({
      ...defaults,
      ...opts,
      particleCount: Math.floor(count * particleRatio),
    });
  }

  fire(0.25, {
    spread: 26,
    startVelocity: 55,
    colors: ['#E63946', '#3B82F6', '#1E3A8A']
  });

  fire(0.2, {
    spread: 60,
    colors: ['#3B82F6', '#1E3A8A']
  });

  fire(0.35, {
    spread: 100,
    decay: 0.91,
    scalar: 0.8,
    colors: ['#E63946', '#3B82F6']
  });

  fire(0.1, {
    spread: 120,
    startVelocity: 25,
    decay: 0.92,
    scalar: 1.2,
    colors: ['#1E3A8A', '#3B82F6']
  });

  fire(0.1, {
    spread: 120,
    startVelocity: 45,
    colors: ['#E63946', '#3B82F6', '#1E3A8A']
  });
}