import { ResourceSection } from '../types/resource';

export function searchResources(sections: ResourceSection[], query: string): ResourceSection[] {
  if (!query.trim()) return sections;

  const searchTerm = query.toLowerCase().trim();

  return sections.map(section => ({
    ...section,
    items: section.items.filter(item => {
      const titleMatch = item.title.toLowerCase().includes(searchTerm);
      const descriptionMatch = item.description?.toLowerCase().includes(searchTerm);
      return titleMatch || descriptionMatch;
    })
  })).filter(section => section.items.length > 0);
}